function y = getbase(x)
%GETBASE (overloaded sdpvar/getbase on double)

% Author Johan L�fberg
% $Id: getbase.m,v 1.2 2005/01/20 18:37:06 johanl Exp $

y = x(:);
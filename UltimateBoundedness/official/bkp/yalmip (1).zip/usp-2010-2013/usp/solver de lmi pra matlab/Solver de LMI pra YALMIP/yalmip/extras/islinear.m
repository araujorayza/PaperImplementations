function p = islinear(x)
p = (1==1);

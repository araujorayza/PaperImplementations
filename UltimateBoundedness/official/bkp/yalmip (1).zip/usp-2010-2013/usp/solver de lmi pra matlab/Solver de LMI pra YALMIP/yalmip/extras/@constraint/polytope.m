function P = polytope(C)
%POLYTOPE (Overloaded)

% Author Johan L�fberg
% $Id: polytope.m,v 1.1 2006/12/07 13:53:54 joloef Exp $

P = polytope(set(C));
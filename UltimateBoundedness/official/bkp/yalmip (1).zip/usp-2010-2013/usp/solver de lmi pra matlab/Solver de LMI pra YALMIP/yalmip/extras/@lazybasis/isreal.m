function res = isreal(Y)
%ISREAL (overloaded)

% Author Johan L�fberg 
% $Id: isreal.m,v 1.1 2005/10/12 16:05:54 joloef Exp $   

res = isreal(Y.sX);

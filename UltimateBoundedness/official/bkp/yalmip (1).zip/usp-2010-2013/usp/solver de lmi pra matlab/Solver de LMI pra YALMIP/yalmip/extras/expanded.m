function X = expanded(F,state)

if nargin == 1
    X = 1;
else    
    X = [];
end